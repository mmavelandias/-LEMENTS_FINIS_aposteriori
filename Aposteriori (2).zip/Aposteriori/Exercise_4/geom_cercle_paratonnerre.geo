Mesh.MshFileVersion = 2.2;
Mesh.Algorithm = 2;

// definition du pas du maillage
l = 0.01;
h = 0.3;
h_arc = l / 4; // Paso fino en la punta para que no colapse cuando l = 0.05
a = 15;
b = 3.6;
L = 1.5;

// definition des points du domaine
Point(1) = {-a/2, -b/2, 0, h};
Point(2) = {a/2, -b/2, 0, h};
Point(3) = {a/2, b/2, 0, h};
Point(4) = {-a/2, b/2, 0, h};

// Paratonnerre
Point(5) = {-l/2, -b/2,     0, h};
Point(6) = {-l/2, -b/2 + L, 0, h_arc};
Point(7) = { l/2, -b/2 + L, 0, h_arc};
Point(8) = { l/2, -b/2,     0, h};

// Pointe demi-cercle (Solo el centro geométrico, sin Point 10)
Point(9) = {0, -b/2 + L, 0, h_arc};

// definition des segments qui relient les points
Line(1) = {1, 5};
Line(2) = {8, 2};
Line(3) = {2, 3};
Line(4) = {3, 4};
Line(5) = {4, 1};
Line(6) = {5, 6};
Line(7) = {7, 8};

// Un solo arco de círculo (de 6 a 7 pasando por encima)
Circle(8) = {7, 9, 6};

// definition des contours fermes (sin el 9)
Curve Loop(1) = {1, 6, -8, 7, 2, 3, 4, 5};
Plane Surface(1) = {1};

// definition des elements physiques (sin el 9)
Physical Point(1) = {1, 2, 3, 4};
Physical Curve(1) = {1, 2, 6, 7, 8};
Physical Curve(2) = {4};
Physical Curve(3) = {5, 3};
Physical Surface(1) = {1};