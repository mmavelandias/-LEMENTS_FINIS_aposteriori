function [err_u_l2, err_u_h1] = Solution_chaleur(nom_maillage)
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% resolution_chaleur :
% Calcule le erreur pour une maillage de taille h caracteristique.
%
% SYNOPSIS resolution_chaleur(nom_maillage)
%
% INPUT * nom_maillage : Le nom du maillage de taille caracteristique h.
%
% OUTPUT - err_L2, err_H1, h.
%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

alpha = 1; 
%% lecture du maillage et affichage
%% ---------------------------------
[Nbpt, Nbtri, Coorneu, Refneu, Numtri, Reftri] = lecture_msh(nom_maillage);
%% ----------------------
%% calcul des matrices EF
%% ----------------------

%% declarations
%% ------------
KK = sparse(Nbpt, Nbpt);
MM = sparse(Nbpt, Nbpt);

%% boucle sur les triangles
%% ------------------------
for l = 1:Nbtri
    S1 = Coorneu(Numtri(l,1),:);
    S2 = Coorneu(Numtri(l,2),:);
    S3 = Coorneu(Numtri(l,3),:);
    Kel = matK_elem(S1, S2, S3, Reftri(l), 3);
    Mel = matM_elem(S1, S2, S3);
    for i = 1:3
        for j = 1:3
            I = Numtri(l,i);  J = Numtri(l,j);
            KK(I,J) = KK(I,J) + Kel(i,j);
            MM(I,J) = MM(I,J) + Mel(i,j);
        end
    end
end
AA = alpha*MM + KK;

%% Calcul du second membre L
%% -------------------------
FF = zeros(Nbpt,1);
for i = 1:Nbpt
    xf = Coorneu(i,1);
    yf = Coorneu(i,2);
    FF(i) = f(xf,yf);
end
LL = MM * FF;

%% Pseudo elimination - consideration de la condition de Dirichlet non - Homogène
[tilde_AA, tilde_LL] = elimine(AA,LL,Refneu,Coorneu);

%% inversion
%% ----------
UU = tilde_AA\tilde_LL;
TT = UU;

%% Erreurs
UU_ref = sin(pi*Coorneu(:,1)) .* sin(2*pi*Coorneu(:,2));
EE = TT - UU_ref;
err_u_l2 = sqrt(EE' * MM * EE);
err_u_semih1 = sqrt(EE' * KK * EE);
err_u_h1     = sqrt(err_u_l2^2 + err_u_semih1^2);

% % %% Après avoir faire la question 14, ou on calcule grad_elem.m, on peut trouver l'erreur h1 de manière rigureusse
% % 
% % M_hat = [1/3 1/3; 1/5 1/5; 3/5 1/5; 3/5 3/5];     
% % poids   = [-9/32, 25/96, 25/96, 25/96];             
% % 
% % err_L2_analy = 0;  
% % err_semiH1_analy = 0;
% % for l = 1:Nbtri
% %     II = Numtri(l,:);
% %     S1 = Coorneu(II(1),:); 
% %     S2 = Coorneu(II(2),:); 
% %     S3 = Coorneu(II(3),:);
% %     G = grad_elem(S1,S2,S3);                  
% %     grad_h = TT(II)' * G;                         
% %     detA = abs((S2(1)-S1(1))*(S3(2)-S1(2)) - (S3(1)-S1(1))*(S2(2)-S1(2)));
% % 
% %     for q = 1:4
% %         x_hat = M_hat(q,1); 
% %         y_hat = M_hat(q,2);
% %         Fl_M_hat  = S1 + x_hat*(S2-S1) + y_hat*(S3-S1); % C'est la transformation: Fl_M_hat = Al * [x_hat; y_hat] + Bl, mais pour
% %         % les points de quadrature (à l'interieur du triangle);   
% %         Th = TT(II)' * [1-x_hat-y_hat; x_hat; y_hat]; % Evaluation de la fonction dans chaque point de quadrature  
% %         T_ext = sin(pi*Fl_M_hat(1))*sin(2*pi*Fl_M_hat(2)); % Evaluation de la fonction exacte dans chaque point de quadrature
% %         g_ext = [pi*cos(pi*Fl_M_hat(1))*sin(2*pi*Fl_M_hat(2)), 2*pi*sin(pi*Fl_M_hat(1))*cos(2*pi*Fl_M_hat(2))]; % Gradient T_ext
% %         err_semiH1_analy = err_semiH1_analy + poids(q)*detA*sum((g_ext - grad_h).^2);
% %     end
% % end
% % err_u_h1  = sqrt(err_u_l2 + err_semiH1_analy);

end