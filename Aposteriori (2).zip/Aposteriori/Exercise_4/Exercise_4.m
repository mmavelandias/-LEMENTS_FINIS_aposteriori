%% =====================================================
%
% une routine pour la mise en oeuvre des EF P1 Lagrange
% pour l'equation de la chaleur suivante stationnaire, avec conditions de
% Dirichlet non homogene
%
% | \alpha T - div(\lambda \grad T) = S,   dans \Omega=\Omega_1 U \Omega_2
% |        T = T_\Gamma,   sur le bord
%
% ou S est la source de chaleur, T_\Gamma la température exterieure
% \alpha > 0 et
% \sigma = | \sigma_1 dans \Omega_1
%          | \sigma_2 dans \Omega_2
%
% =====================================================

clear all; close all;
nom_maillage = 'geom_paratonnerre_pointu_adapt_0.3.mesh';
validation   = 'non';
raffinement  = 'non';
reference    = 'non';

alpha   = 0;
T_Gamma = 0;

%% lecture du maillage et affichage
%% ---------------------------------
%[Nbpt,Nbtri,Coorneu,Refneu,Numtri,Reftri,Nbaretes,Numaretes,Refaretes]=lecture_msh(nom_maillage);
[Nbpt,Nbtri,Coorneu,Refneu,Numtri,Reftri,Nbaretes,Numaretes,Refaretes]=lecture_inria_medit_mesh(nom_maillage);
% Nbpt
figure(2); affiche(Refneu, Numtri, Coorneu, 'Refneu');
%% ----------------------
%% calcul des matrices EF
%% ----------------------

%% declarations
%% ------------
KK = sparse(Nbpt,Nbpt); % matrice de rigidite
MM = sparse(Nbpt,Nbpt); % matrice de rigidite
LL = zeros(Nbpt,1);     % vecteur second membre

%% boucle sur les triangles
%% ------------------------
for l=1:Nbtri
  %% Coordonnees des sommets du triangles
  S1=Coorneu(Numtri(l,1),:);
  S2=Coorneu(Numtri(l,2),:);
  S3=Coorneu(Numtri(l,3),:);

  % calcul des matrices elementaires du triangle l 
   %Matrice de rigidité
   Kel=matK_elem(S1, S2, S3, Reftri(l),3);
   %Matrice de masse
   Mel=matM_elem(S1, S2, S3);
   %En faisant l'assemblage de la matrice globale, suivant le pseudo
   %algotime du amphi 4.
  for i = 1:3
    I = Numtri(l,i);
    for j = 1:3
        J = Numtri(l,j);
        KK(I,J) = KK(I,J) + Kel(i,j);
        MM(I,J) = MM(I,J) + Mel(i,j);
    end
  end   
end % for l

AA = alpha*MM + KK;

%% Calcul du second membre L
%% -------------------------
FF = zeros(Nbpt,1);
for i = 1:Nbpt
    xf = Coorneu(i,1);
    yf = Coorneu(i,2);
    FF(i) = f(xf,yf);
end
LL = MM * FF;

%% Pseudo elimination - consideration de la condition de Dirichlet non - Homogène
[tilde_AA, tilde_LL] = elimine(AA,LL,Refneu,Coorneu);

%% inversion
%% ----------
UU = tilde_AA\tilde_LL;
TT = UU; %% UU considere toutes les valeurs de reponse (pour l'interieur, et les frontières) 

%% visualisation
%% -------------
figure(2); affiche(TT, Numtri, Coorneu, sprintf('Vh - %s', nom_maillage));

%% Calcul de grad(u_h) par triangle
%% --------------------------------
grad_uh = zeros(Nbtri, 2);
for l=1:Nbtri

  %% Indices globaux des sommets du triangle
  II = Numtri(l,:);

  %% Coordonnees des sommets du triangle
  S1=Coorneu(II(1),:);
  S2=Coorneu(II(2),:);
  S3=Coorneu(II(3),:);
  % Calcul du gradient des fonctions de base sur un triangle
  grad_w_i = grad_elem(S1, S2, S3);
  % Valeurs nodales de la solution sur ce triangle
  Ti = TT(II);
  %% grad(u_h) = somme_k T_k * grad(w_k)
  grad_uh(l,:) = Ti' * grad_w_i;
end


%% Calcul de sigma_h comme une moyenne de -grad(u_h) par patch
%% -----------------------------------------------------------
Sigma = zeros(Nbpt,2);
Sigma(:,1) = moyenne_par_patch(-grad_uh(:,1), Numtri, Coorneu);
Sigma(:,2) = moyenne_par_patch(-grad_uh(:,2), Numtri, Coorneu);

% figure(3); affiche(Sigma(:,1), Numtri, Coorneu, 'sigma_x');
% figure(4); affiche(Sigma(:,2), Numtri, Coorneu, 'sigma_y');
% |Norme sigma_h|
norme_E = sqrt(Sigma(:,1).^2 + Sigma(:,2).^2);
figure(5); affiche(norme_E, Numtri, Coorneu, '|E|'); % Pour l'exercise 4 Sigma_h est E

% Valeur maximale de E
E_max = max(norme_E);
fprintf('Valeur maximale |E| egal a : %.2f V/m\n', E_max);

%% Estimateur d'erreur
% %% -------------------
Eta = zeros(Nbtri, 1);
Eta_r2 = 0;  %% Composante en résidu
Eta_f2 = 0;  %% Composante en flux
for l = 1:Nbtri
  %% Indices des sommets du triangle
  II = Numtri(l,:);

  %% Coordonnees des sommets du triangle
  S1=Coorneu(II(1),:);
  S2=Coorneu(II(2),:);
  S3=Coorneu(II(3),:);
  
  % X = Coorneu(II,1);
  % Y = Coorneu(II,2);

  %% Matrices élémentaires
  M_el = matM_elem(S1, S2, S3);
  g_el = grad_elem(S1, S2, S3);

  %% Composante en flux :
  %% E_f  = grad(u_h) + sigma_h
  %% E_f2 = || Ef ||^2_{L2}
  E_fx = grad_uh(l,1) + Sigma(II,1); 
  E_fy = grad_uh(l,2) + Sigma(II,2); 
  E_f2 = E_fx' * M_el * E_fx + E_fy' * M_el * E_fy;

  %% Composante en résidu :
  %% E_r  = f - div(sigma_h) - u_h
  %% E_r2 = || E_r ||^2_{L2}
  gradSigmaX = Sigma(II,1)' * g_el; % [d(sigma_x)/dx, d(sigma_x)/dy]
  gradSigmaY = Sigma(II,2)' * g_el; % [d(sigma_y)/dx, d(sigma_y)/dy]
  divSigma   = gradSigmaX(1) + gradSigmaY(2); 
  
  E_r  = FF(II) - divSigma - alpha * TT(II); 
  E_r2 = E_r' * M_el * E_r;

  %% Estimateur global
  Eta_f2 = Eta_f2 + E_f2; % La Somme pour chaque triangle
  Eta_r2 = Eta_r2 + E_r2;
  Eta(l) = sqrt(E_f2) + 15.426/pi * sqrt(E_r2); % Eta pour chaque triangle individuèllement
end

%% Estimateur global
Eta_tot = sqrt(Eta_f2) + 2*sqrt(2)/pi * sqrt(Eta_r2); % Eta total, c'est l'estimation d'erreur a posteriori (12)

%% Lissage de l'estimateur par triangle, pour visualisation et post-traitement
Eta_av = moyenne_par_patch(Eta, Numtri, Coorneu); % Les valeurs d'Eta dans chaque node, est le moyennage d'Eta de chaque triangle
% qui entourne le node
figure(6); affiche(Eta_av, Numtri, Coorneu, 'Eta');

%% validation
%% ----------
if strcmp(validation,'oui')
  X = Coorneu(:,1);
  Y = Coorneu(:,2);
  
  % %% CAS I : REFERENCE ANALYTIQUE
  % UU_ref = sin(pi*X) .* sin(2*pi*Y);
  % Sigma_ref = zeros(Nbpt, 2);
  % Sigma_ref(:,1) = -pi   * cos(pi*X) .* sin(2*pi*Y);
  % Sigma_ref(:,2) = -2*pi * sin(pi*X) .* cos(2*pi*Y);
  
  %% CAS II : REFERENCE NON ANALYTIQUE
  %% Récupération de la référence
  %% et interpolation sur le maillage courant
  % [UU_ref, Sigma_ref] = lecture_reference(X, Y);
  % 
  % %% Erreur sur u
  % EE = (UU - UU_ref);
  % 
  % figure(7); affiche(abs(EE), Numtri, Coorneu, sprintf('Erreur - %s', nom_maillage));
  % figure(8); affiche(UU_ref, Numtri, Coorneu, sprintf('U_exact'));
  % 
  % %% Calcul de l erreur L2 sur u_h
  % err_u_l2 = sqrt(EE' * MM * EE); 
  % %% Calcul de l erreur en semi-norme H1 sur u_h
  % err_u_semih1 = sqrt(EE' * KK * EE);

l_vals = [0.3, 0.2, 0.1, 0.05];
na = length(l_vals);

maill_pointu = {'geom_paratonnerre_pointu_0.3.mesh', 'geom_paratonnerre_pointu_0.2.mesh', 'geom_paratonnerre_pointu_0.1.mesh', 'geom_paratonnerre_pointu_0.05.mesh'};
maill_pointu_a = {'geom_paratonnerre_pointu_adapt_0.3.mesh', 'geom_paratonnerre_pointu_adapt_0.2.mesh', 'geom_paratonnerre_pointu_adapt_0.1.mesh', 'geom_paratonnerre_pointu_adapt_0.05.mesh'};

maill_circle = {'geom_paratonnerre_cercle_0.3.mesh', 'geom_paratonnerre_cercle_0.2.mesh', 'geom_paratonnerre_cercle_0.1.mesh', 'geom_paratonnerre_cercle_0.05.mesh'};
maill_circle_a = {'geom_paratonnerre_cercle_adapt_0.3.mesh', 'geom_paratonnerre_cercle_adapt_0.2.mesh', 'geom_paratonnerre_cercle_adapt_0.1.mesh', 'geom_paratonnerre_cercle_adapt_0.05.mesh'};

% Vectores para guardar los resultados
Emax_pointu = zeros(na,1); 
Emax_l0_a = zeros(na,1);
Emax_circle = zeros(na,1); 
Emax_circle_a = zeros(na,1);

for k = 1:na
    % Aquí llamamos a una función que calcula E_max (equivalente a tu Solution_chaleur_aposteriori)
    % Si calculas dentro de este mismo script sin función, deberás meter el ensamblaje aquí dentro.
    Emax_pointu(k)  = calcul_Emax(maill_pointu{k});
    Emax_l0_a(k)  = calcul_Emax(maill_pointu_a{k});
    Emax_circle(k) = calcul_Emax(maill_circle{k});
    Emax_circle_a(k) = calcul_Emax(maill_circle_a{k});
    
    fprintf('l = %.2f | Emax Tri In: %.1f | Tri Ad: %.1f | Circ In: %.1f | Circ Ad: %.1f\n', ...
        l_vals(k), Emax_pointu(k), Emax_l0_a(k), Emax_circle(k), Emax_circle_a(k));
end

%% 3. Trazado de las 4 líneas
figure(12);

plot(l_vals, Emax_pointu, 'b*-', 'LineWidth', 1, 'MarkerFaceColor', 'b', 'DisplayName', 'Pointe pointue'); 
hold on; grid on;
plot(l_vals, Emax_l0_a, 'b--s', 'LineWidth', 1, 'MarkerFaceColor', 'b', 'DisplayName', 'Pointe pointue adaptée');

plot(l_vals, Emax_circle, 'r-*', 'LineWidth', 1, 'MarkerFaceColor', 'r', 'DisplayName', 'Pointe demi-cercle');
plot(l_vals, Emax_circle_a, 'r--s', 'LineWidth', 1, 'MarkerFaceColor', 'r', 'DisplayName', 'Pointe demi-cercle adaptée');

set(gca, 'XDir', 'reverse');

% Etiquetas
xlabel('Largeur du paratonnerre l (m)');
ylabel('|E|_{max} (V/m)');
title('Evolution de |E|_{max}');
legend('Location', 'best');


%% BONUS l = 0 
figure(13);

[Nbpt_l0, ~, ~, ~, ~, ~, ~, ~, ~] = lecture_inria_medit_mesh('geom_paratonnerre_l_0_0.3.mesh');
[Nbpt_l0_adapt, ~, ~, ~, ~, ~, ~, ~, ~] = lecture_inria_medit_mesh('geom_paratonnerre_l_0_adapt.mesh'); 
[Nbpt_l0_adapt_2, ~, ~, ~, ~, ~, ~, ~, ~] = lecture_inria_medit_mesh('geom_paratonnerre_l_0_adapt_2.mesh'); 
[Nbpt_l0_adapt_3, ~, ~, ~, ~, ~, ~, ~, ~] = lecture_inria_medit_mesh('geom_paratonnerre_l_0_adapt_3.mesh'); 

Emax_l0 = calcul_Emax('geom_paratonnerre_l_0_0.3.mesh');
Emax_l0_a = calcul_Emax('geom_paratonnerre_l_0_adapt.mesh');
Emax_l0_a_2 = calcul_Emax('geom_paratonnerre_l_0_adapt_2.mesh');
Emax_l0_a_3 = calcul_Emax('geom_paratonnerre_l_0_adapt_3.mesh');

etapes = [0, 1, 2, 3];
Nbpt_todos = [Nbpt_l0, Nbpt_l0_adapt, Nbpt_l0_adapt_2, Nbpt_l0_adapt_3];
Emax_adapt_l0 = [Emax_l0_a, Emax_l0_a_2, Emax_l0_a_3];

plot(etapes, [Emax_l0, Emax_adapt_l0], 'b--', 'LineWidth', 1.2, 'HandleVisibility', 'off'); 
hold on; 
grid on;
plot(0, Emax_l0, 'b*', 'MarkerSize', 10, 'LineWidth', 1.5, 'DisplayName', 'l = 0');
plot(etapes(2:end), Emax_adapt_l0, 'rs', 'MarkerSize', 8, 'MarkerFaceColor', 'r', 'DisplayName', 'l = 0 (Adaptées)');

Emax_total = [Emax_l0, Emax_adapt_l0];
for k = 1:length(etapes)
    text(etapes(k)+0.1, Emax_total(k)-100, sprintf('  Nbpt = %d', Nbpt_todos(k)),'VerticalAlignment', 'bottom', 'FontSize', 9);
end

xticks(etapes);
xlim([0, 3.75]);
ylim([0, 4000]);
xlabel('Étape d''adaptation');
ylabel('|E|_{max} (V/m)');
legend('Location', 'northwest');

  % %% Erreur sur sigma
  % EEx = Sigma(:,1) - Sigma_ref(:,1);
  % EEy = Sigma(:,2) - Sigma_ref(:,2);
  % 
  % %% Calcul de l'erreur L2 sur sigma_h
  % err_sigma_l2 = sqrt(EEx'*MM*EEx + EEy'*MM*EEy);
end

%% Adaptation du maillage
if strcmp(raffinement, 'oui')
  h_tri = zeros(Nbtri,1);
  for l = 1:Nbtri
      P = Coorneu(Numtri(l,:),:);
      h_tri(l) = mean([norm(P(1,:)-P(2,:)), norm(P(2,:)-P(3,:)), norm(P(3,:)-P(1,:))]);
  end
  h_old = moyenne_par_patch(h_tri, Numtri, Coorneu);
  h = h_old ./ Eta_av;     % Calcul du nouveau pas de maillage
  h_min = 0.01; %%%%%%
  h = h * h_min/min(h); % - mise à l'échelle pour que : min(h) == 0.01
  % Descendre plus que 0.01 n'a pas de sens, notre reference est de h = 0.01
  h = min(h, 0.4);     % - écrêtement pour que :       max(h) <= 0.4
  fprintf('Entrada: %s | Nbpt=%d | min(h)=%.4f max(h)=%.4f\n', nom_maillage, Nbpt, min(h), max(h));
  figure(6); affiche(h, Numtri, Coorneu, 'h')

  %% Génération des fichiers pour gmsh
  %%
  %% Commande pour générer un maillage raffiné :
  %%   gmsh -bgm size.pos geomCarre.geo
  write_field('size.pos', 'Mesh size', h, Numtri, Coorneu);
  system('C:\Users\carlo\Downloads\gmsh-4.14.0-Windows64\gmsh-4.14.0-Windows64\gmsh.exe -2 -bgm size.pos geom_paratonnerre.geo -format mesh -o geom_paratonnerre_adapt_0.3.mesh');
end

%% Enregistrement des résultats de référence (si maillage suffisamment raffiné)
if strcmp(reference, 'oui')
  dx = 1e-3;
  X = Coorneu(:,1);
  Y = Coorneu(:,2);
  Xrange = min(X):dx:max(X);
  Yrange = min(Y):dx:max(Y);
  [XI,YI] = meshgrid(Xrange, Yrange);
  Uref      = griddata(X,Y,UU,        XI,YI);
  SigmaXref = griddata(X,Y,Sigma(:,1),XI,YI);
  SigmaYref = griddata(X,Y,Sigma(:,2),XI,YI);
  save 'ref.mat' Xrange Yrange Uref SigmaXref SigmaYref
end

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%                                                        fin de la routine
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%2026
