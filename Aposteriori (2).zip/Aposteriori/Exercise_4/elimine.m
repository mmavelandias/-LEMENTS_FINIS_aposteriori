function [AAE,LLE] = elimine(AA,LL,Refneu,Coorneu)

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% elimine :
% Routine qui fait la pseudo-elimination pour les noeuds avec Refneu(i) = 1
% Conditions aux limites Dirichlet homogenes.
%
% SYNOPSIS elimine(AA,LL,Refneu)
%
% INPUT * AA, LL, Refneu: La matrice et le second membre associes au
% probleme sans elimination et references des noeuds sur la frontiere
% Dirichlet.
%
% OUTPUT - AAE, LLE: On rend la matrice et le second membre une fois la
% pseudo elimination realisee.
%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

% Nous allons verifier chaque noued donc nous verifions sur toute la
% quantité de noeuds
Nbpt = size(Refneu,1);
cond_g = 0;
% On adapte l'Algorithme 4 presente dans le chapitre 6 du Poly
for i = 1:Nbpt
    xg = Coorneu(i, 1);
    yg = Coorneu(i, 2);
    if Refneu(i) == 1
        cond_g = 0;
    elseif Refneu(i) == 2
        cond_g = g(xg,yg);
    else
        continue
    end
    % On fait la pseudo - elimination
    AA(i, :) = 0;
    AA(i, i) = 1;
    LL(i) = cond_g;
% Il faut noter que la matrice resultante n'est pas symétrique, mais
% a priori n'est pas grave car avec l'operateur \, Matlab cherche
% l'algoritme le plus efficace pour resoudre cette matrice
% (problème si on cherchait un methode que prend en compte la
% symetrie)
% Pour ce cas on ajoute après le boucle: LL = LL - AA(:, i) * g(xg, yg);
% Et AA(:,i) = 0, en obtenant ainsis une matrice simetrique.
end

% On copie la matrice AA et le second membre dans AAE et LLE.
AAE = AA;
LLE = LL;

%% A COMPLETER


%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%                                                       fin de la fonction
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%2026
