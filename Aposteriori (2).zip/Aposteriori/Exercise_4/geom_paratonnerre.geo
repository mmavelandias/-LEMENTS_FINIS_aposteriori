Mesh.MshFileVersion = 2.2;
Mesh.Algorithm = 2;

// definition du pas du maillage
l = 0.01;
h = 0.3;
a = 15;
b = 3.6;
L = 1.5;

// definition des points (en 3D, raison pour laquelle il y a un 0 en z)
Point(1) = {-a/2, -b/2, 0, h};
Point(2) = {a/2, -b/2, 0, h};
Point(3) = {a/2, b/2, 0, h};
Point(4) = {-a/2, b/2, 0, h};
// Paratonnerre
Point(5) = {-l/2, -b/2,       0, h};
Point(6) = {-l/2, -b/2 + L,   0, h};
Point(7) = { l/2, -b/2 + L,   0, h};
Point(8) = { l/2, -b/2,       0, h};

// Efet de pointe
// Pointe pointue
Point(9) = {0, -b/2 + L + h, 0, h};

// definition des segments qui relient les points

Line(1) = {1, 5};
Line(2) = {8, 2};
Line(3) = {2, 3};
Line(4) = {3, 4};
Line(5) = {4, 1};
Line(6) = {5, 6};
Line(7) = {7, 8};

// Efet de pointe
// Pointe pointue
Line(8) = {6, 9};
Line(9) = {9, 7};

// definition des contours fermes
Curve Loop(1) = {1, 6, 8, 9,  7, 2, 3, 4, 5};
Plane Surface(1) = {1};

// definition des elements physiques : pour ces elements, nous pourrons recuperer
// les references
Physical Point(1) = {1,2,3,4};
Physical Curve(1) = {1, 2, 6, 7, 8, 9};
Physical Curve(2) = {4};
Physical Curve(3) = {5, 3};
Physical Surface(1) = {1};




// //Paratonnerre avec (l = 0)
// Point(5) = {0, -b/2, 0, h};
// Point(6) = {0, -b/2 + L + h, 0, h};
// //definition des segments qui relient les points
// Line(1) = {1, 5};
// Line(2) = {5, 2};
// Line(3) = {2, 3};
// Line(4) = {3, 4};
// Line(5) = {4, 1};
// Line(6) = {5, 6};

// //l = 0
// Line Loop(1) = {1, 2, 3, 4, 5};
// Plane Surface(1) = {1};
// Line{6} In Surface{1};

// //l = 0
// Physical Point(1) = {1,2,3,4};
// Physical Curve(1) = {1, 2, 6};
// Physical Curve(2) = {4};
// Physical Curve(3) = {5, 3};
// Physical Surface(1) = {1};