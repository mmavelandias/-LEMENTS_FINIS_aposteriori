function E_max = calcul_Emax(nom_maillage)
    [Nbpt,Nbtri,Coorneu,Refneu,Numtri,Reftri,~,~,~] = lecture_inria_medit_mesh(nom_maillage);

    Ii = zeros(9*Nbtri,1);
    Jj = zeros(9*Nbtri,1);
    Kv = zeros(9*Nbtri,1);
    cpt = 0;
    
    for l = 1:Nbtri
        S1 = Coorneu(Numtri(l,1),:);
        S2 = Coorneu(Numtri(l,2),:);
        S3 = Coorneu(Numtri(l,3),:);
        Kel = matK_elem(S1, S2, S3, Reftri(l), 3);   
        % Mel = matM_elem(S1, S2, S3);                 
        for i = 1:3
            I = Numtri(l,i);
            for j = 1:3
                J = Numtri(l,j);
                cpt = cpt + 1;
                Ii(cpt) = I;
                Jj(cpt) = J;
                Kv(cpt) = Kel(i,j);
                % Mv(cpt) = Mel(i,j);
            end
        end
    end
    
    KK = sparse(Ii, Jj, Kv, Nbpt, Nbpt);   
    % MM = sparse(Ii, Jj, Mv, Nbpt, Nbpt);
    
    AA = KK; 
    
    LL = zeros(Nbpt,1); 
    
    [tilde_AA, tilde_LL] = elimine(AA, LL, Refneu, Coorneu);
    
    TT = tilde_AA \ tilde_LL;
    
    grad_uh = zeros(Nbtri, 2);
    for l=1:Nbtri
        II = Numtri(l,:);
        S1=Coorneu(II(1),:);
        S2=Coorneu(II(2),:);
        S3=Coorneu(II(3),:);
        
        grad_w_i = grad_elem(S1, S2, S3);
        Ti = TT(II);
        grad_uh(l,:) = Ti' * grad_w_i;
    end
    
    Sigma = zeros(Nbpt,2);
    Sigma(:,1) = moyenne_par_patch(-grad_uh(:,1), Numtri, Coorneu);
    Sigma(:,2) = moyenne_par_patch(-grad_uh(:,2), Numtri, Coorneu);
    
    norme_E = sqrt(Sigma(:,1).^2 + Sigma(:,2).^2);
    E_max = max(norme_E);
    
    % Visualisation désactivée pour la boucle (décommenter si besoin)
    % figure; affiche(norme_E, Numtri, Coorneu, '|E|'); 
    % fprintf('Valeur maximale |E| pour %s : %.2f V/m\n', nom_maillage, E_max);
end