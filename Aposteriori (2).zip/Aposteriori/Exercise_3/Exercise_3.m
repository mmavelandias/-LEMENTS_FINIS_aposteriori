%% =====================================================
%
% une routine pour la mise en oeuvre des EF P1 Lagrange
% pour l'equation de la chaleur suivante stationnaire, avec conditions de
% Dirichlet non homogene
%
% | \alpha T - div(\lambda \grad T) = S,   dans \Omega=\Omega_1 U \Omega_2
% |        T = T_\Gamma,   sur le bord
%
% ou S est la source de chaleur, T_\Gamma la température exterieure
% \alpha > 0 et
% \sigma = | \sigma_1 dans \Omega_1
%          | \sigma_2 dans \Omega_2
%
% =====================================================

clear all; close all;
nom_maillage = 'geomChaleur_adapt_0.01.msh';
validation   = 'oui';
raffinement  = 'non';
reference    = 'non';

alpha   = 1;
T_Gamma = 0;

%% lecture du maillage et affichage
%% ---------------------------------
[Nbpt,Nbtri,Coorneu,Refneu,Numtri,Reftri,Nbaretes,Numaretes,Refaretes]=lecture_msh(nom_maillage);
%[Nbpt,Nbtri,Coorneu,Refneu,Numtri,Reftri,Nbaretes,Numaretes,Refaretes]=lecture_inria_medit_mesh(nom_maillage);
% Nbpt

%% ----------------------
%% calcul des matrices EF
%% ----------------------

%% declarations
%% ------------
KK = sparse(Nbpt,Nbpt); % matrice de rigidite
MM = sparse(Nbpt,Nbpt); % matrice de rigidite
LL = zeros(Nbpt,1);     % vecteur second membre

%% boucle sur les triangles
%% ------------------------
for l=1:Nbtri
  %% Coordonnees des sommets du triangles
  S1=Coorneu(Numtri(l,1),:);
  S2=Coorneu(Numtri(l,2),:);
  S3=Coorneu(Numtri(l,3),:);

  % calcul des matrices elementaires du triangle l 
   %Matrice de rigidité
   Kel=matK_elem(S1, S2, S3, Reftri(l),3);
   %Matrice de masse
   Mel=matM_elem(S1, S2, S3);
   %En faisant l'assemblage de la matrice globale, suivant le pseudo
   %algotime du amphi 4.
  for i = 1:3
    I = Numtri(l,i);
    for j = 1:3
        J = Numtri(l,j);
        KK(I,J) = KK(I,J) + Kel(i,j);
        MM(I,J) = MM(I,J) + Mel(i,j);
    end
  end   
end % for l

AA = alpha*MM + KK;

%% Calcul du second membre L
%% -------------------------
FF = zeros(Nbpt,1);
for i = 1:Nbpt
    xf = Coorneu(i,1);
    yf = Coorneu(i,2);
    FF(i) = f(xf,yf);
end
LL = MM * FF;

%% Pseudo elimination - consideration de la condition de Dirichlet non - Homogène
[tilde_AA, tilde_LL] = elimine(AA,LL,Refneu,Coorneu);

%% inversion
%% ----------
UU = tilde_AA\tilde_LL;
TT = UU; %% UU considere toutes les valeurs de reponse (pour l'interieur, et les frontières) 


%% visualisation
%% -------------
figure(1); affiche(TT, Numtri, Coorneu, sprintf('Uh - %s', nom_maillage));

%% Calcul de grad(u_h) par triangle
%% --------------------------------
grad_uh = zeros(Nbtri, 2);
for l=1:Nbtri

  %% Indices globaux des sommets du triangle
  II = Numtri(l,:);

  %% Coordonnees des sommets du triangle
  S1=Coorneu(II(1),:);
  S2=Coorneu(II(2),:);
  S3=Coorneu(II(3),:);
  % Calcul du gradient des fonctions de base sur un triangle
  grad_w_i = grad_elem(S1, S2, S3);
  % Valeurs nodales de la solution sur ce triangle
  Ti = TT(II);
  %% grad(u_h) = somme_k T_k * grad(w_k)
  grad_uh(l,:) = Ti' * grad_w_i;
end


%% Calcul de sigma_h comme une moyenne de -grad(u_h) par patch
%% -----------------------------------------------------------
Sigma = zeros(Nbpt,2);
Sigma(:,1) = moyenne_par_patch(-grad_uh(:,1), Numtri, Coorneu);
Sigma(:,2) = moyenne_par_patch(-grad_uh(:,2), Numtri, Coorneu);

% figure(2); affiche(Sigma(:,1), Numtri, Coorneu, 'sigma_x');
% figure(3); affiche(Sigma(:,2), Numtri, Coorneu, 'sigma_y');
% |Norme sigma_h|
% norme_sigma = sqrt(Sigma(:,1).^2 + Sigma(:,2).^2);
% figure(4); affiche(norme_sigma, Numtri, Coorneu, '|\sigma_h|');

%% Estimateur d'erreur
% %% -------------------
Eta = zeros(Nbtri, 1);
Eta_r2 = 0;  %% Composante en résidu
Eta_f2 = 0;  %% Composante en flux
for l = 1:Nbtri
  %% Indices des sommets du triangle
  II = Numtri(l,:);

  %% Coordonnees des sommets du triangle
  S1=Coorneu(II(1),:);
  S2=Coorneu(II(2),:);
  S3=Coorneu(II(3),:);
  
  % X = Coorneu(II,1);
  % Y = Coorneu(II,2);

  %% Matrices élémentaires
  M_el = matM_elem(S1, S2, S3);
  g_el = grad_elem(S1, S2, S3);

  %% Composante en flux :
  %% E_f  = grad(u_h) + sigma_h
  %% E_f2 = || Ef ||^2_{L2}
  E_fx = grad_uh(l,1) + Sigma(II,1); 
  E_fy = grad_uh(l,2) + Sigma(II,2); 
  E_f2 = E_fx' * M_el * E_fx + E_fy' * M_el * E_fy;

  %% Composante en résidu :
  %% E_r  = f - div(sigma_h) - u_h
  %% E_r2 = || E_r ||^2_{L2}
  gradSigmaX = Sigma(II,1)' * g_el; % [d(sigma_x)/dx, d(sigma_x)/dy]
  gradSigmaY = Sigma(II,2)' * g_el; % [d(sigma_y)/dx, d(sigma_y)/dy]
  divSigma   = gradSigmaX(1) + gradSigmaY(2); 
  
  E_r  = FF(II) - divSigma - TT(II); 
  E_r2 = E_r' * M_el * E_r;

  %% Estimateur global
  Eta_f2 = Eta_f2 + E_f2; % La Somme pour chaque triangle
  Eta_r2 = Eta_r2 + E_r2;
  Eta(l) = sqrt(E_f2) + 2*sqrt(2)/pi * sqrt(E_r2); % Eta pour chaque triangle individuèllement
end

%% Estimateur global
Eta_tot = sqrt(Eta_f2) + 2*sqrt(2)/pi * sqrt(Eta_r2); % Eta total, c'est l'estimation d'erreur a posteriori (12)

%% Lissage de l'estimateur par triangle, pour visualisation et post-traitement
Eta_av = moyenne_par_patch(Eta, Numtri, Coorneu); % Les valeurs d'Eta dans chaque node, est le moyennage d'Eta de chaque triangle
% qui entourne le node
figure(5); affiche(Eta_av, Numtri, Coorneu, 'Eta');

%% validation
%% ----------
if strcmp(validation,'oui')
  X = Coorneu(:,1);
  Y = Coorneu(:,2);
  
  % %% CAS I : REFERENCE ANALYTIQUE
  % UU_ref = sin(pi*X) .* sin(2*pi*Y);
  % Sigma_ref = zeros(Nbpt, 2);
  % Sigma_ref(:,1) = -pi   * cos(pi*X) .* sin(2*pi*Y);
  % Sigma_ref(:,2) = -2*pi * sin(pi*X) .* cos(2*pi*Y);
  
  %% CAS II : REFERENCE NON ANALYTIQUE
  %% Récupération de la référence
  %% et interpolation sur le maillage courant
  [UU_ref, Sigma_ref] = lecture_reference(X, Y);
    
  %% Erreur sur u
  EE = (UU - UU_ref);

  figure(7); affiche(abs(EE), Numtri, Coorneu, sprintf('Erreur - %s', nom_maillage));
  figure(8); affiche(UU_ref, Numtri, Coorneu, sprintf('U_exact'));

  %% Calcul de l erreur L2 sur u_h
  err_u_l2 = sqrt(EE' * MM * EE); 
  %% Calcul de l erreur en semi-norme H1 sur u_h
  err_u_semih1 = sqrt(EE' * KK * EE);

  %% Evolution des quantites ||T_ref - T||_H1 et Eta
  maill_a = {'geomChaleur_h_0.1.msh','geomChaleur_adapt_0.09.msh','geomChaleur_adapt_0.08.msh','geomChaleur_adapt_0.07.msh','geomChaleur_adapt_0.06.msh','geomChaleur_adapt_0.05.msh','geomChaleur_adapt_0.04.msh','geomChaleur_adapt_0.03.msh','geomChaleur_adapt_0.02.msh','geomChaleur_adapt_0.01.msh'};
  na = numel(maill_a);
  Np_a = zeros(na,1);  
  err_a = zeros(na,1);  eta_a = zeros(na,1);
    
  for k = 1:na
      [~, err_a(k), eta_a(k), Np_a(k)] = Solution_chaleur_aposteriori(maill_a{k}, 2);
      fprintf('%s | Nbpt=%d | errH1=%.3e | eta=%.3e\n', maill_a{k}, Np_a(k), err_a(k), eta_a(k));
  end
    
%% Calculs pour diferents maillages
  maill_u = {'geomChaleur_h_0.1.msh', 'geomChaleur_h_0.09.msh', 'geomChaleur_h_0.08.msh', 'geomChaleur_h_0.07.msh', 'geomChaleur_h_0.06.msh', 'geomChaleur_h_0.05.msh', 'geomChaleur_h_0.04.msh', 'geomChaleur_h_0.03.msh', 'geomChaleur_h_0.02.msh'};
  h_u     = [0.1 0.09 0.08 0.07 0.06 0.05 0.04 0.03 0.02];
  nu = numel(maill_u);
  Np_u = zeros(nu,1);  
  err_u = zeros(nu,1);  
  eta_u = zeros(nu,1);
  for k = 1:nu
      [~, err_u(k), eta_u(k), Np_u(k)] = Solution_chaleur_aposteriori(maill_u{k}, 2);
      fprintf('%s | Nbpt=%d | errH1=%.3e | eta=%.3e\n', maill_u{k}, Np_u(k), err_u(k), eta_u(k));
  end

  %% Comparaison de l'erreur avec le numero de points
  figure(9);
  plot(log(Np_u), log(err_u), 'b*-', 'LineWidth',1, 'DisplayName','H1 uniforme'); hold on; grid on;
  plot(log(Np_a), log(err_a), 'rs-', 'LineWidth',1, 'DisplayName','H1 adaptada');
  xlabel('log(N_{pt})'); ylabel('log(erreur H^1)'); legend;

  %% Comparaison d'Eta avec le numero de points
  figure(10);
  plot(log(Np_u), log(eta_u), 'b*-', 'LineWidth',1, 'DisplayName','\eta_h uniforme'); hold on; grid on;
  plot(log(Np_a), log(eta_a), 'ms-', 'LineWidth',1, 'DisplayName','\eta_h adaptada');
  xlabel('log(N_{pt})'); ylabel('log(\eta_h)'); legend;

  %% Comparation de l'Erreur et Eta avec h
  
  h_a = [0.1 0.09 0.08 0.07 0.06 0.05 0.04 0.03 0.02 0.01];
  figure(11);
  plot(log(1./h_u), log(err_u), 'b*-', 'DisplayName','H1 uniforme'); hold on; grid on;
  plot(log(1./h_a), log(err_a), 'rs-', 'DisplayName','H1 adaptada (h = hmin)');
  plot(log(1./h_u), log(eta_u), 'c*-', 'DisplayName','\eta_h uniforme');
  plot(log(1./h_a), log(eta_a), 'ms-', 'DisplayName','\eta_h adaptada (h = hmin)');
  xlabel('log(1/h)'); ylabel('log(erreur)'); legend;

  %% Erreur sur sigma
  EEx = Sigma(:,1) - Sigma_ref(:,1);
  EEy = Sigma(:,2) - Sigma_ref(:,2);

  %% Calcul de l'erreur L2 sur sigma_h
  err_sigma_l2 = sqrt(EEx'*MM*EEx + EEy'*MM*EEy);
end

%% Raffinement du maillage
if strcmp(raffinement, 'oui')
  h_tri = zeros(Nbtri,1);
  for l = 1:Nbtri
      P = Coorneu(Numtri(l,:),:);
      h_tri(l) = mean([norm(P(1,:)-P(2,:)), norm(P(2,:)-P(3,:)), norm(P(3,:)-P(1,:))]);
  end
  h_old = moyenne_par_patch(h_tri, Numtri, Coorneu);
  h = h_old ./ Eta_av;     % Calcul du nouveau pas de maillage
  h_min = 0.01; %%%%%%
  h = h * h_min/min(h); % - mise à l'échelle pour que : min(h) == 0.01
  % Descendre plus que 0.01 n'a pas de sens, notre reference est de h = 0.01
  h = min(h, 0.4);     % - écrêtement pour que :       max(h) <= 0.4
  fprintf('Entrada: %s | Nbpt=%d | min(h)=%.4f max(h)=%.4f\n', nom_maillage, Nbpt, min(h), max(h));
  figure(6); affiche(h, Numtri, Coorneu, 'h')

  %% Génération des fichiers pour gmsh
  %%
  %% Commande pour générer un maillage raffiné :
  %%   gmsh -bgm size.pos geomCarre.geo
  write_field('size.pos', 'Mesh size', h, Numtri, Coorneu);
  system('C:\Users\carlo\Downloads\gmsh-4.14.0-Windows64\gmsh-4.14.0-Windows64\gmsh.exe -2 -bgm size.pos geomChaleur.geo -format msh2 -o geomChaleur_adapt_0.01.msh');
end

%% Enregistrement des résultats de référence (si maillage suffisamment raffiné)
if strcmp(reference, 'oui')
  dx = 1e-3;
  X = Coorneu(:,1);
  Y = Coorneu(:,2);
  Xrange = min(X):dx:max(X);
  Yrange = min(Y):dx:max(Y);
  [XI,YI] = meshgrid(Xrange, Yrange);
  Uref      = griddata(X,Y,UU,        XI,YI);
  SigmaXref = griddata(X,Y,Sigma(:,1),XI,YI);
  SigmaYref = griddata(X,Y,Sigma(:,2),XI,YI);
  save 'ref.mat' Xrange Yrange Uref SigmaXref SigmaYref
end

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%                                                        fin de la routine
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%2026
