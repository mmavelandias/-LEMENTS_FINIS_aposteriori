function [Kel] = matK_elem(S1, S2, S3, Reftri, Nq)
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% mat_elem :
% calcul la matrice de raideur elementaire en P1 lagrange
%
% SYNOPSIS [Kel] = mat_elem(S1, S2, S3)
%
% INPUT * S1, S2, S3 : les 2 coordonnees des 3 sommets du triangle
%                      (vecteurs reels 1x2)
%
% OUTPUT - Kel matrice de raideur elementaire (matrice 3x3)
%
% NOTE (1) le calcul est exacte (pas de condensation de masse)
%      (2) calcul par passage a l'element de reference
%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%


% preliminaires, pour faciliter la lecture:
x1 = S1(1); y1 = S1(2);
x2 = S2(1); y2 = S2(2);
x3 = S3(1); y3 = S3(2);

% calcul de la matrice de raideur
% -------------------------------
Kel = zeros(3,3);
M_hat = zeros(2, Nq);

%Points et poids de quadrature
if Nq == 3 % Numero de points de quadrature
    M_hat(:,1) = [1/6; 1/6]; % Pour la première ligne de M_hat, on a les valeurs pour x_hat; Pour la deuxième ligne, on a les valeurs pour y_hat;
    M_hat(:,2) = [2/3; 1/6];
    M_hat(:,3) = [1/6; 2/3];
    poids = [1/6, 1/6, 1/6];
elseif Nq == 4
    M_hat(:,1) = [1/3; 1/3];
    M_hat(:,2) = [1/5; 1/5];
    M_hat(:,3) = [3/5; 1/5];
    M_hat(:,4) = [1/5; 3/5];
    poids = [-9/32, 25/96, 25/96, 25/96];
else
    error('Dans la fonction matK_elem: Nq doit valoir 3 ou 4');
end


% Definición de matrices Al y vector Bl
Al = [x2-x1 x3-x1; y2-y1 y3-y1];
Bl = [x1;y1];

% Calculo términos de llenado matriz Kelem
detAl = abs(det(Al));
invA_T = (inv(Al))';
grad_w_hat = [-1 -1; 1 0; 0 1]'; %grad(w_hat_i), 1<=i<=3
grad_w = invA_T * grad_w_hat;

%Llenado de matriz Kelem
for n = 1:Nq
    % Coordonées S_hat
    x_hat = M_hat(1, n);
    y_hat = M_hat(2, n);

    % Mapeo a triangulo real Tl
    Fl_M_hat = Al * [x_hat; y_hat] + Bl;
    
    if Reftri == 1
        lambda = lambda1(Fl_M_hat(1), Fl_M_hat(2));
    elseif Reftri == 2
        lambda = lambda2(Fl_M_hat(1), Fl_M_hat(2));
    else
        error('Dans la fonction matK_elem: Reftri %d non reconnue, Reftri doit être 1 ou 2', Reftri)
    end

    for i = 1:3
        for j = 1:3
            dot_prod_w = grad_w(:, i)' * grad_w(:, j); % Produit escalaire grad_wi * grad_wj
            Kel(i, j) = Kel(i, j) + poids(n) * lambda * dot_prod_w * detAl;
        end
    end    
end

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%                                                        fin de la routine
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%2026
