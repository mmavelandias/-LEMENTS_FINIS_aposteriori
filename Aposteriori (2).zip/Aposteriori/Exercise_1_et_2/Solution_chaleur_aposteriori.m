function [h_err_L2, h_err_h1, Eta_tot, Nbpt, Eta_av, Numtri, Coorneu, h_old] = Solution_chaleur_aposteriori(nom_maillage, cas)
alpha = 1;

[Nbpt, Nbtri, Coorneu, Refneu, Numtri, Reftri] = lecture_msh(nom_maillage);
X = Coorneu(:,1);
Y = Coorneu(:,2);

%% Ensamblage
KK = sparse(Nbpt,Nbpt); 
MM = sparse(Nbpt,Nbpt);
for l=1:Nbtri
  %% Coordonnees des sommets du triangles
  S1=Coorneu(Numtri(l,1),:);
  S2=Coorneu(Numtri(l,2),:);
  S3=Coorneu(Numtri(l,3),:);

  Kel=matK_elem(S1, S2, S3, Reftri(l), 3);
  Mel=matM_elem(S1, S2, S3);
  for i = 1:3
    I = Numtri(l,i);
    for j = 1:3
        J = Numtri(l,j);
        KK(I,J) = KK(I,J) + Kel(i,j);
        MM(I,J) = MM(I,J) + Mel(i,j);
    end
  end   
end % for l
AA = alpha*MM + KK;

FF = zeros(Nbpt,1);
for i = 1:Nbpt
    xf = Coorneu(i,1);
    yf = Coorneu(i,2);
    FF(i) = f(xf,yf);
end
LL = MM * FF;

[tilde_AA, tilde_LL] = elimine(AA, LL, Refneu, Coorneu);
TT = tilde_AA \ tilde_LL;

%% Calcul de grad(u_h) par triangle
%% --------------------------------
grad_uh = zeros(Nbtri, 2);
for l=1:Nbtri

  %% Indices globaux des sommets du triangle
  II = Numtri(l,:);

  %% Coordonnees des sommets du triangle
  S1=Coorneu(II(1),:);
  S2=Coorneu(II(2),:);
  S3=Coorneu(II(3),:);
  % Calcul du gradient des fonctions de base sur un triangle
  grad_w_i = grad_elem(S1, S2, S3);
  % Valeurs nodales de la solution sur ce triangle
  Ti = TT(II);
  %% grad(u_h) = somme_k T_k * grad(w_k)
  grad_uh(l,:) = Ti' * grad_w_i;
end
Sigma = zeros(Nbpt,2);
Sigma(:,1) = moyenne_par_patch(-grad_uh(:,1), Numtri, Coorneu);
Sigma(:,2) = moyenne_par_patch(-grad_uh(:,2), Numtri, Coorneu);

%% Estimateur
Eta = zeros(Nbtri, 1);
Eta_r2 = 0;  %% Composante en résidu
Eta_f2 = 0;  %% Composante en flux
for l = 1:Nbtri
  %% Indices des sommets du triangle
  II = Numtri(l,:);

  %% Coordonnees des sommets du triangle
  S1=Coorneu(II(1),:);
  S2=Coorneu(II(2),:);
  S3=Coorneu(II(3),:);
  
  % X = Coorneu(II,1);
  % Y = Coorneu(II,2);

  %% Matrices élémentaires
  M_el = matM_elem(S1, S2, S3);
  g_el = grad_elem(S1, S2, S3);

  %% Composante en flux :
  %% E_f  = grad(u_h) + sigma_h
  %% E_f2 = || Ef ||^2_{L2}
  E_fx = grad_uh(l,1) + Sigma(II,1); 
  E_fy = grad_uh(l,2) + Sigma(II,2); 
  E_f2 = E_fx' * M_el * E_fx + E_fy' * M_el * E_fy;

  %% Composante en résidu :
  %% E_r  = f - div(sigma_h) - u_h
  %% E_r2 = || E_r ||^2_{L2}
  gradSigmaX = Sigma(II,1)' * g_el; % [d(sigma_x)/dx, d(sigma_x)/dy]
  gradSigmaY = Sigma(II,2)' * g_el; % [d(sigma_y)/dx, d(sigma_y)/dy]
  divSigma   = gradSigmaX(1) + gradSigmaY(2); 
  
  E_r  = FF(II) - divSigma - TT(II); 
  E_r2 = E_r' * M_el * E_r;

  %% Estimateur global
  Eta_f2 = Eta_f2 + E_f2; % La Somme pour chaque triangle
  Eta_r2 = Eta_r2 + E_r2;
  Eta(l) = sqrt(E_f2) + 2*sqrt(2)/pi * sqrt(E_r2);
end
%% Estimateur global
Eta_tot = sqrt(Eta_f2) + 2*sqrt(2)/pi * sqrt(Eta_r2);
Eta_av = moyenne_par_patch(Eta, Numtri, Coorneu);
%% T_ref CAS I et CAS II

if cas == 1
    M_hat = [1/3 1/3; 1/5 1/5; 3/5 1/5; 1/5 3/5];     
    poids   = [-9/32, 25/96, 25/96, 25/96];             

    err_L2_analy = 0;  
    err_semiH1_analy = 0;
    for l = 1:Nbtri
        II = Numtri(l,:);
        S1 = Coorneu(II(1),:); 
        S2 = Coorneu(II(2),:); 
        S3 = Coorneu(II(3),:);
        G = grad_elem(S1,S2,S3);                  
        grad_h = TT(II)' * G;                         
        detA = abs((S2(1)-S1(1))*(S3(2)-S1(2)) - (S3(1)-S1(1))*(S2(2)-S1(2)));

        for q = 1:4
            x_hat = M_hat(q,1); 
            y_hat = M_hat(q,2);
            Fl_M_hat  = S1 + x_hat*(S2-S1) + y_hat*(S3-S1); % C'est la transformation: Fl_M_hat = Al * [x_hat; y_hat] + Bl, mais pour
            % les points de quadrature (à l'interieur du triangle);   
            Th = TT(II)' * [1-x_hat-y_hat; x_hat; y_hat]; % Evaluation de la fonction dans chaque point de quadrature  
            T_ext = sin(pi*Fl_M_hat(1))*sin(2*pi*Fl_M_hat(2)); % Evaluation de la fonction exacte dans chaque point de quadrature
            g_ext = [pi*cos(pi*Fl_M_hat(1))*sin(2*pi*Fl_M_hat(2)), 2*pi*sin(pi*Fl_M_hat(1))*cos(2*pi*Fl_M_hat(2))]; % Gradie
            err_L2_analy = err_L2_analy + poids(q)*detA*(T_ext - Th)^2;
            err_semiH1_analy = err_semiH1_analy + poids(q)*detA*sum((g_ext - grad_h).^2);
        end
    end
    h_err_L2 = sqrt(err_L2_analy);
    h_err_h1 = sqrt(err_L2_analy + err_semiH1_analy);
else
    [UU_ref, Sigma_ref] = lecture_reference(X, Y);
    EE = TT - UU_ref;
    h_err_L2   = sqrt(EE'*MM*EE);
    err_semih1 = sqrt(EE'*KK*EE);
    h_err_h1     = sqrt(h_err_L2^2 + err_semih1^2);

% Calcul du nouveau
h_tri = zeros(Nbtri,1);
for l = 1:Nbtri
    P = Coorneu(Numtri(l,:),:);
    h_tri(l) = mean([norm(P(1,:)-P(2,:)), norm(P(2,:)-P(3,:)), norm(P(3,:)-P(1,:))]);
end
h_old = moyenne_par_patch(h_tri, Numtri, Coorneu);

end